package com.clinica.service;

import com.clinica.dto.MedicoRequest;
import com.clinica.entity.Especialidad;
import com.clinica.entity.Medico;
import com.clinica.exception.RecursoNoEncontradoException;
import com.clinica.repository.EspecialidadRepository;
import com.clinica.repository.MedicoRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MedicoService {

    private final MedicoRepository medicoRepo;
    private final EspecialidadRepository especialidadRepo;

    public MedicoService(MedicoRepository medicoRepo,
                         EspecialidadRepository especialidadRepo) {
        this.medicoRepo = medicoRepo;
        this.especialidadRepo = especialidadRepo;
    }

    public List<Medico> listar() {
        return medicoRepo.findAll();
    }

    public Medico buscar(Long id) {
        return medicoRepo.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Médico no encontrado"));
    }

    public Medico crear(MedicoRequest dto) {
        Medico m = new Medico();
        copiarDatos(m, dto);
        return medicoRepo.save(m);
    }

    public Medico actualizar(Long id, MedicoRequest dto) {
        Medico actual = buscar(id);
        copiarDatos(actual, dto);
        return medicoRepo.save(actual);
    }

    public void eliminar(Long id) {
        Medico actual = buscar(id);
        medicoRepo.delete(actual);
    }

    // La relación se resuelve en el Service: la especialidad debe existir
    private void copiarDatos(Medico m, MedicoRequest dto) {
        Especialidad esp = especialidadRepo.findById(dto.getEspecialidadId())
                .orElseThrow(() -> new RecursoNoEncontradoException("Especialidad no encontrada"));
        m.setNombre(dto.getNombre());
        m.setTarifa(dto.getTarifa());
        m.setCupos(dto.getCupos());
        m.setEspecialidad(esp);
    }
}
